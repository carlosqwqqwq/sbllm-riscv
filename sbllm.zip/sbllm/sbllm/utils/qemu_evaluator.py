"""
QEMU RISC-V 评估器模块

用于在 QEMU 仿真环境中运行和评估 RISC-V 代码的性能。
支持功能正确性检查、性能评估和代码大小分析。
"""
import os
import re
import hashlib
import shutil
import subprocess
import tempfile
import time
import pandas as pd
from typing import Tuple, List, Optional, Dict
from functools import lru_cache
import logging
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import ThreadPoolExecutor, as_completed
# from .code_utils import sanitize_c_code # Moved to riscv_compiler
from .riscv_compiler import RISCVCompiler

logger = logging.getLogger(__name__)


class QEMURISCVEvaluator:
    """
    QEMU RISC-V 评估器类
    
    用于编译、运行和评估 RISC-V 代码的性能指标。
    """
    
    def __init__(self, qemu_path: str, riscv_gcc_toolchain_path: str, temp_dir: Optional[str] = None,
                 enable_cache: bool = True, max_workers: int = 4):
        """
        初始化 QEMU RISC-V 评估器
        
        Args:
            qemu_path: QEMU 可执行文件路径（如 qemu-riscv64）
            riscv_gcc_toolchain_path: RISC-V GCC 工具链路径（包含 bin 目录的路径）
            temp_dir: 临时文件目录，如果为 None 则使用系统临时目录
            enable_cache: 是否启用编译缓存
            max_workers: 并行评估的最大工作线程数
        """
        self.qemu_path = qemu_path
        self.riscv_gcc_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-gcc')
        self.riscv_as_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-as')
        self.riscv_objdump_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-objdump')
        self.riscv_size_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-size')
        self.temp_dir = temp_dir or tempfile.gettempdir()
        self.enable_cache = enable_cache
        self.max_workers = max_workers
        
        # Initialize Compiler
        self.compiler = RISCVCompiler(riscv_gcc_toolchain_path, self.temp_dir, enable_cache)
        
        # 验证路径是否存在
        if not os.path.exists(self.qemu_path):
            raise FileNotFoundError(f"QEMU path not found: {self.qemu_path}")
    
    
    def compile_to_riscv_binary(self, code: str, output_bin: str, use_cache: bool = True) -> bool:
        """
        Delegates compilation to RISCVCompiler.
        """
        return self.compiler.compile_to_riscv_binary(code, output_bin, use_cache)

    def run_and_measure(self, binary_path: str, input_data: Optional[str] = None, 
                       num_runs: int = 5, reference_output: Optional[str] = None) -> Tuple[float, int, bool, Optional[str]]:
        """
        使用 qemu-riscv64 运行二进制文件，测量执行时间和代码大小，并验证功能正确性
        
        Args:
            binary_path: 二进制文件路径
            input_data: 输入数据（可选）
            num_runs: 运行次数，用于计算平均时间
            reference_output: 参考输出（用于功能正确性检查，可选）
        
        Returns:
            (execution_time, code_size, is_correct, output)
            - execution_time: 平均执行时间（秒）
            - code_size: 代码段大小（字节）
            - is_correct: 功能是否正确（通过输出比较或返回码判断）
            - output: 程序输出（用于比较）
        """
        if not os.path.exists(binary_path):
            logger.error(f"Binary file not found: {binary_path}")
            return 99999.0, 0, False, None
        
        # 测量代码大小
        code_size = self._get_code_size(binary_path)
        
        # 运行并测量时间
        execution_times = []
        outputs = []
        is_correct = True
        
        for _ in range(num_runs):
            try:
                # 准备输入
                input_file_path = None
                if input_data:
                    input_file = tempfile.NamedTemporaryFile(mode='w', delete=False, dir=self.temp_dir, suffix='.txt')
                    input_file.write(input_data)
                    input_file.close()
                    input_file_path = input_file.name
                
                # 测量执行时间
                start_time = time.perf_counter()
                if input_file_path:
                    with open(input_file_path, 'r') as f:
                        result = subprocess.run(
                            [self.qemu_path, binary_path],
                            stdin=f,
                            capture_output=True,
                            text=True,
                            timeout=10
                        )
                    os.unlink(input_file_path)
                else:
                    result = subprocess.run(
                        [self.qemu_path, binary_path],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                end_time = time.perf_counter()
                
                execution_times.append(end_time - start_time)
                output = result.stdout.strip()
                outputs.append(output)
                
                # 检查返回码（非零可能表示错误）
                if result.returncode != 0:
                    is_correct = False
                    logger.warning(f"Binary returned non-zero exit code: {result.returncode}, stderr: {result.stderr[:200]}")
                
                # 如果有参考输出，进行比较
                if reference_output is not None:
                    if not self._compare_outputs(output, reference_output):
                        is_correct = False
                        logger.debug(f"Output mismatch. Expected: {reference_output[:100]}, Got: {output[:100]}")
                    
            except subprocess.TimeoutExpired:
                logger.warning(f"Execution timeout for {binary_path}")
                execution_times.append(99999.0)
                is_correct = False
            except Exception as e:
                logger.error(f"Execution error: {e}")
                execution_times.append(99999.0)
                is_correct = False
            finally:
                # 确保清理临时文件
                if input_file_path and os.path.exists(input_file_path):
                    try:
                        os.unlink(input_file_path)
                    except:
                        pass
        
        # 计算平均执行时间
        avg_time = sum(execution_times) / len(execution_times) if execution_times else 99999.0
        
        # 使用最常见的输出作为最终输出
        final_output = max(set(outputs), key=outputs.count) if outputs else None
        
        return avg_time, code_size, is_correct, final_output
    
    def _compare_outputs(self, output1: str, output2: str, tolerance: float = 1e-6) -> bool:
        """
        比较两个输出是否相同（支持数值容差）
        
        Args:
            output1: 第一个输出
            output2: 第二个输出
            tolerance: 数值比较的容差
        
        Returns:
            是否相同
        """
        # 去除首尾空白
        output1 = output1.strip()
        output2 = output2.strip()
        
        # 完全匹配
        if output1 == output2:
            return True
        
        # 逐行比较（支持数值容差）
        lines1 = output1.splitlines()
        lines2 = output2.splitlines()
        
        if len(lines1) != len(lines2):
            return False
        
        for line1, line2 in zip(lines1, lines2):
            if line1 == line2:
                continue
            
            # 尝试数值比较
            try:
                val1 = float(line1)
                val2 = float(line2)
                if abs(val1 - val2) > tolerance:
                    return False
            except ValueError:
                # 不是数值，必须完全匹配
                return False
        
        return True
    
    def _get_code_size(self, binary_path: str) -> int:
        """
        获取二进制文件的代码段大小
        
        Args:
            binary_path: 二进制文件路径
        
        Returns:
            代码段大小（字节）
        """
        try:
            # 使用 size 命令获取代码段大小
            size_cmd = [self.riscv_size_path, binary_path]
            result = subprocess.run(size_cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                # 解析 size 输出
                lines = result.stdout.strip().split('\n')
                if len(lines) >= 2:
                    # 第二行包含实际大小信息
                    parts = lines[1].split()
                    if len(parts) >= 2:
                        # text 段大小（代码段）
                        return int(parts[0])
            
            # 如果 size 命令失败，使用 objdump 估算
            return self._estimate_code_size_from_objdump(binary_path)
            
        except Exception as e:
            logger.warning(f"Failed to get code size: {e}")
            return self._estimate_code_size_from_objdump(binary_path)
    
    def _estimate_code_size_from_objdump(self, binary_path: str) -> int:
        """
        使用 objdump 估算代码大小
        
        Args:
            binary_path: 二进制文件路径
        
        Returns:
            估算的代码大小（字节）
        """
        try:
            objdump_cmd = [self.riscv_objdump_path, '-d', binary_path]
            result = subprocess.run(objdump_cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                # 统计指令行数（粗略估算）
                lines = result.stdout.split('\n')
                instruction_count = sum(1 for line in lines if re.match(r'\s+[0-9a-f]+:', line))
                # 假设平均每条指令 4 字节（RISC-V 标准指令长度）
                return instruction_count * 4
            
            return 0
        except Exception as e:
            logger.warning(f"Failed to estimate code size: {e}")
            return 0
    
    def evaluate_candidates(self, original_code: str, candidate_codes: List[str],
                          original_binary_path: Optional[str] = None,
                          input_data: Optional[str] = None) -> pd.DataFrame:
        """
        对每个候选代码进行评估，返回包含性能指标的 DataFrame
        
        Args:
            original_code: 原始代码
            candidate_codes: 候选代码列表
            original_binary_path: 原始代码的二进制文件路径（可选，如果提供则直接使用）
            input_data: 输入测试数据（可选）
        
        Returns:
            包含以下字段的 DataFrame:
            - candidate_id: 候选代码索引
            - code: 候选代码
            - execution_time: 执行时间（秒）
            - code_size: 代码大小（字节）
            - is_correct: 是否正确
            - speedup_ratio: 加速比 (1 - new_time/old_time)
            - size_reduction_ratio: 体积缩减率
        """
        results = []
        
        # 编译并评估原始代码
        if original_binary_path and os.path.exists(original_binary_path):
            original_bin = original_binary_path
            original_time, original_size, _, _ = self.run_and_measure(original_bin, input_data, num_runs=5)
        else:
            original_bin = os.path.join(self.temp_dir, 'original.bin')
            if not self.compile_to_riscv_binary(original_code, original_bin):
                logger.error("Failed to compile original code")
                original_time = 99999.0
                original_size = 0
            else:
                original_time, original_size, _, _ = self.run_and_measure(original_bin, input_data, num_runs=5)
        
        # 评估每个候选代码
        for idx, candidate_code in enumerate(candidate_codes):
            candidate_bin = os.path.join(self.temp_dir, f'candidate_{idx}.bin')
            
            if not self.compile_to_riscv_binary(candidate_code, candidate_bin):
                logger.warning(f"Failed to compile candidate {idx}")
                results.append({
                    'candidate_id': idx,
                    'code': candidate_code,
                    'execution_time': 99999.0,
                    'code_size': 0,
                    'is_correct': False,
                    'speedup_ratio': 0.0,
                    'size_reduction_ratio': 0.0
                })
                continue
            
            exec_time, code_size, is_correct, _ = self.run_and_measure(candidate_bin, input_data, num_runs=5)
            
            # 计算加速比
            if original_time > 0:
                speedup_ratio = 1 - (exec_time / original_time)
            else:
                speedup_ratio = 0.0
            
            # 计算体积缩减率
            if original_size > 0:
                size_reduction_ratio = (original_size - code_size) / original_size
            else:
                size_reduction_ratio = 0.0
            
            results.append({
                'candidate_id': idx,
                'code': candidate_code,
                'execution_time': exec_time,
                'code_size': code_size,
                'is_correct': is_correct,
                'speedup_ratio': speedup_ratio,
                'size_reduction_ratio': size_reduction_ratio
            })
            
            # 清理临时文件
            try:
                if os.path.exists(candidate_bin):
                    os.remove(candidate_bin)
            except Exception as e:
                logger.warning(f"Failed to remove temporary file {candidate_bin}: {e}")
        
        # 清理原始代码的临时文件
        if not original_binary_path:
            try:
                if os.path.exists(original_bin):
                    os.remove(original_bin)
            except Exception as e:
                logger.warning(f"Failed to remove temporary file {original_bin}: {e}")
        
        return pd.DataFrame(results)
    
    def evaluate_candidates_parallel(self, original_code: str, candidate_codes: List[str],
                                    original_binary_path: Optional[str] = None,
                                    input_data: Optional[str] = None,
                                    reference_output: Optional[str] = None) -> pd.DataFrame:
        """
        并行评估多个候选代码（性能优化版本）
        
        Args:
            original_code: 原始代码
            candidate_codes: 候选代码列表
            original_binary_path: 原始代码的二进制文件路径（可选）
            input_data: 输入测试数据（可选）
            reference_output: 参考输出（用于功能正确性检查，可选）
        
        Returns:
            包含性能指标的 DataFrame
        """
        # 先编译并评估原始代码
        if original_binary_path and os.path.exists(original_binary_path):
            original_bin = original_binary_path
            original_time, original_size, original_correct, _ = self.run_and_measure(
                original_bin, input_data, num_runs=5, reference_output=reference_output
            )
        else:
            original_bin = os.path.join(self.temp_dir, 'original.bin')
            if not self.compile_to_riscv_binary(original_code, original_bin):
                logger.error("Failed to compile original code")
                original_time = 99999.0
                original_size = 0
                original_correct = False
            else:
                original_time, original_size, original_correct, _ = self.run_and_measure(
                    original_bin, input_data, num_runs=5, reference_output=reference_output
                )
        
        # 并行评估候选代码
        def evaluate_single_candidate(args):
            idx, candidate_code = args
            candidate_bin = os.path.join(self.temp_dir, f'candidate_{idx}.bin')
            
            if not self.compile_to_riscv_binary(candidate_code, candidate_bin):
                logger.warning(f"Failed to compile candidate {idx}")
                return {
                    'candidate_id': idx,
                    'code': candidate_code,
                    'execution_time': 99999.0,
                    'code_size': 0,
                    'is_correct': False,
                    'speedup_ratio': 0.0,
                    'size_reduction_ratio': 0.0
                }
            
            exec_time, code_size, is_correct, _ = self.run_and_measure(
                candidate_bin, input_data, num_runs=5, reference_output=reference_output
            )
            
            # 计算加速比
            if original_time > 0:
                speedup_ratio = 1 - (exec_time / original_time)
            else:
                speedup_ratio = 0.0
            
            # 计算体积缩减率
            if original_size > 0:
                size_reduction_ratio = (original_size - code_size) / original_size
            else:
                size_reduction_ratio = 0.0
            
            # 清理临时文件
            try:
                if os.path.exists(candidate_bin):
                    os.remove(candidate_bin)
            except Exception as e:
                logger.warning(f"Failed to remove temporary file {candidate_bin}: {e}")
            
            return {
                'candidate_id': idx,
                'code': candidate_code,
                'execution_time': exec_time,
                'code_size': code_size,
                'is_correct': is_correct,
                'speedup_ratio': speedup_ratio,
                'size_reduction_ratio': size_reduction_ratio
            }
        
        # 使用线程池并行执行
        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [executor.submit(evaluate_single_candidate, (idx, code)) 
                      for idx, code in enumerate(candidate_codes)]
            
            for future in as_completed(futures):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    logger.error(f"Error evaluating candidate: {e}")
        
        # 清理原始代码的临时文件
        if not original_binary_path:
            try:
                if os.path.exists(original_bin):
                    os.remove(original_bin)
            except Exception as e:
                logger.warning(f"Failed to remove temporary file {original_bin}: {e}")
        
        return pd.DataFrame(results)

