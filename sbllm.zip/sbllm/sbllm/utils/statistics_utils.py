
import logging
import yaml
import os

logger = logging.getLogger(__name__)

def write_yaml(data, file_path):
    with open(file=file_path, mode='w', encoding='utf8') as f:
        yaml.dump(data, f)

def calculate_statistics(execution_data, cfg):
    """
    Calculate and print statistics based on execution data.
    """
    results = []
    references = []
    hypothesis = []
    ptr = 0
    correct = 0
    faster_count = 0
    unique_count = 0
    input_time_sum = 0
    generated_test_sum = 0
    unique_reference_time_sum = 0
    unique_generated_test_sum = 0

    for i in execution_data:
        acc = i.get('model_generated_potentially_faster_code_col_acc', 0)
        input_time = i.get('input_time_mean', 0)
        generated_time = i.get('model_generated_potentially_faster_code_col_time_mean', input_time)
        reference_time = i.get('reference_time_mean', input_time)
        
        if input_time is None or reference_time is None:
            continue
        
        if generated_time is None:
            generated_time = input_time
            
        results.append([generated_time, input_time, acc])
        
        # Collect hypothesis codes (not strictly used in stats printing but logic was present)
        for num in range(5):
            time_key = f'model_generated_potentially_faster_code_col_{num}_time_mean'
            std_key = f'model_generated_potentially_faster_code_col_{num}_time_std'
            if time_key in i and std_key in i:
                if i[time_key] == i.get('model_generated_potentially_faster_code_col_time_mean') and \
                   i[std_key] == i.get('model_generated_potentially_faster_code_col_time_std', 0.0):
                    references.append([i.get('code_v1_no_empty_lines', '')])
                    code_key = f'model_generated_potentially_faster_code_col_{num}'
                    hypothesis.append(i.get(code_key, ''))
                    break
        
        if acc==1:
            correct+=1
        
        if acc==1 and generated_time < input_time:
            if generated_time < reference_time:
                unique_count += 1
                unique_reference_time_sum += reference_time
                unique_generated_test_sum += generated_time
            
            if generated_time < input_time * 0.9:
                faster_count += 1
            
            input_time_sum += input_time
            generated_test_sum += generated_time
            ptr += input_time/generated_time - 1
        else:
            input_time_sum += input_time
            generated_test_sum += input_time
            ptr += 0
            
    print(cfg.mode)
    if len(results) > 0:
        print('OPT(%): ', round(100*faster_count/len(results), 2))
        print('SP: ', round(100*ptr/len(results), 2))
    else:
        print('No results to evaluate')
