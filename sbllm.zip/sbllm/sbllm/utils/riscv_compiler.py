
import os
import re
import hashlib
import shutil
import subprocess
import logging
from typing import Optional, Dict

from .code_utils import sanitize_c_code

logger = logging.getLogger(__name__)

class RISCVCompiler:
    """
    RISC-V Compiler wrapper.
    Handles compilation of C and Assembly code to RISC-V binaries.
    """
    
    def __init__(self, riscv_gcc_toolchain_path: str, temp_dir: str, enable_cache: bool = True):
        self.riscv_gcc_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-gcc')
        self.riscv_as_path = os.path.join(riscv_gcc_toolchain_path, 'bin', 'riscv64-unknown-linux-gnu-as')
        self.temp_dir = temp_dir
        self.enable_cache = enable_cache
        self._compile_cache: Dict[str, str] = {}
        
        if not os.path.exists(self.riscv_gcc_path):
             raise FileNotFoundError(f"RISC-V GCC path not found: {self.riscv_gcc_path}")

    def _get_code_hash(self, code: str) -> str:
        return hashlib.md5(code.encode('utf-8')).hexdigest()

    def _is_assembly_code(self, code: str) -> bool:
        """
        Check if the code is likely assembly.
        """
        # Check for C function signature FIRST
        # Matches patterns like: int foo(int *a, int n) {
        if re.search(r'\b(void|int|long|float|double|char|unsigned)\s+\w+\s*\(.*\)\s*{', code):
            return False

        if "```assembly" in code or "```asm" in code:
            return True
        
        # Heuristics
        markers = ['.global', '.section', '.text', '.data', 'li ', 'mv ', 'ret', 'add ', 'sub ']
        count = sum(1 for m in markers if m in code)
        if count >= 2:
            return True
            
        return False

    def compile_to_riscv_binary(self, code: str, output_bin: str, use_cache: bool = True) -> bool:
        """
        Compiles the code to a RISC-V binary.
        """
        # 1. Sanitize
        code = sanitize_c_code(code)

        # 1.5 Pre-validation (Forbidden patterns)
        forbidden_patterns = [
            ('immintrin.h', 'x86 intrinsic header'),
            ('xmmintrin.h', 'x86 intrinsic header'),
            ('emmintrin.h', 'x86 intrinsic header'),
            ('pmmintrin.h', 'x86 intrinsic header'),
            ('tmmintrin.h', 'x86 intrinsic header'),
            ('smmintrin.h', 'x86 intrinsic header'),
            ('nmmintrin.h', 'x86 intrinsic header'),
            ('wmmintrin.h', 'x86 intrinsic header'),
            ('<iostream>', 'C++ header'),
            ('<vector>', 'C++ header'),
            ('<string>', 'C++ header'),
            ('<algorithm>', 'C++ header'),
            ('using namespace std', 'C++ namespace'),
            ('std::', 'C++ standard library namespace'),
            ('vlw.v', 'Legacy RVV v0.7 instruction (use vle32.v)'),
            ('vsw.v', 'Legacy RVV v0.7 instruction (use vse32.v)'),
            ('vlb.v', 'Legacy RVV v0.7 instruction (use vle8.v)'),
            ('vsb.v', 'Legacy RVV v0.7 instruction (use vse8.v)'),
            ('vle.v', 'Legacy RVV v0.7 instruction (use vle8/16/32/64.v)'),
            ('vse.v', 'Legacy RVV v0.7 instruction (use vse8/16/32/64.v)'),
            ('<unistd.h>', 'Unsafe POSIX header'),
            ('system(', 'Unsafe system call'),
            ('popen(', 'Unsafe process execution'),
            ('execl', 'Unsafe process execution'),
            ('execv', 'Unsafe process execution'),
            ('float32x4_t', 'ARM NEON type (not RISC-V)'),
            ('float16x4_t', 'ARM NEON type (not RISC-V)'),
            ('int32x4_t', 'ARM NEON type (not RISC-V)'),
            ('uint32x4_t', 'ARM NEON type (not RISC-V)'),
            ('float16_t', 'ARM half-precision type (use _Float16 or float)'),
            ('__fp16', 'ARM half-precision type (use _Float16)'),
            ('zicond', 'Unsupported Zicond extension'),
            # cmov: match as instruction (surrounded by whitespace/punctuation)
            ('\tcmov', 'Unsupported conditional move instruction (x86)'),
            (' cmov ', 'Unsupported conditional move instruction (x86)'),
            ('\ncmov', 'Unsupported conditional move instruction (x86)'),
            ('pcnt ', 'Unsupported popcount instruction (use cpop)'),
            ('\tpcnt', 'Unsupported popcount instruction (use cpop)'),
            (' abs ', 'Unsupported abs pseudo-instruction'),
            ('\tabs ', 'Unsupported abs pseudo-instruction'),
            # Removed ` cnt ` - too many false positives with variable names
            ('loopnez', 'Unsupported loop instruction'),
            ('.predict', 'Unsupported prediction directive'),
            (' rev ', 'Unsupported rev instruction (use rev8)'),
            ('pkbb32', 'Unsupported packed SIMD instruction (needs P extension)'),
            ('cmpeq16', 'Unsupported packed SIMD instruction (needs P extension)'),
            ('__builtin_riscv_ctz', 'Non-existent RISC-V builtin (use inline asm)'),
            ('__builtin_riscv_clz', 'Non-existent RISC-V builtin (use inline asm)'),
            ('__builtin_riscv_popcount', 'Non-existent RISC-V builtin (use cpop asm)'),
            ('</The', 'XML/HTML hallucination'),
            ('Here are', 'Explanation text in code'),
            ('```', 'Markdown code fence in code'),
        ]
        
        for pattern, reason in forbidden_patterns:
            if pattern in code:
                logger.error(f"Compilation rejected: Forbidden pattern '{pattern}' detected ({reason}).")
                return False

        # 2. Type detection
        is_assembly = self._is_assembly_code(code)
        
        # 3. Inject Harness and Headers
        if is_assembly:
            if not re.search(r'^\s*main\s*:', code, re.MULTILINE):
                logger.info("Injecting Assembly Harness (main label)")
                harness = "\n\n/* Assembler Harness */\n.section .text\n.global main\nmain:\n    li a0, 0\n    ret\n"
                code += harness
        else:
            # Inject Headers for C
            headers_to_inject = []
            if '<riscv_vector.h>' not in code and '"riscv_vector.h"' not in code:
                headers_to_inject.append('#include <riscv_vector.h>')
            if '<stdint.h>' not in code and '"stdint.h"' not in code:
                headers_to_inject.append('#include <stdint.h>')
            if '<stdio.h>' not in code and '"stdio.h"' not in code:
                headers_to_inject.append('#include <stdio.h>')
            
            if headers_to_inject:
                code = '\n'.join(headers_to_inject) + '\n' + code

            if not re.search(r'\bmain\s*\(', code):
                logger.info("Injecting C Harness (main function)")
                code += "\n\n// Auto-generated harness\nint main() { return 0; }\n"

        # 4. Cache Check
        if self.enable_cache and use_cache:
            code_hash = self._get_code_hash(code)
            if code_hash in self._compile_cache:
                cached_bin = self._compile_cache[code_hash]
                if os.path.exists(cached_bin):
                    try:
                        shutil.copy2(cached_bin, output_bin)
                        logger.debug(f"Using cached binary for code hash {code_hash[:8]}")
                        return True
                    except Exception as e:
                        logger.warning(f"Failed to reuse cached binary: {e}")

        # 5. Write to temp file
        ext = '.s' if is_assembly else '.c'
        with open(output_bin + ext, 'w', encoding='utf-8') as f:
            f.write(code)
        
        source_path = output_bin + ext
        
        # 6. Compile
        cmd = [
            self.riscv_gcc_path,
            source_path,
            '-o', output_bin,
            '-O3',
            '-march=rv64gcv_zba_zbb_zbs_zvbb',  
            '-mabi=lp64d',
            '-static',
            '-fno-tree-vectorize'
        ]
        
        if is_assembly:
            # Assembly specific
            pass
        else:
            # C specific
            cmd.extend(['-lm']) 

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30 # Compilation timeout
            )
            
            if result.returncode != 0:
                logger.error(f"Compilation failed:\n{result.stderr}")
                return False
            
            # 7. Update Cache
            if self.enable_cache and use_cache and result.returncode == 0:
                if os.path.exists(output_bin):
                    cached_path = os.path.join(self.temp_dir, f"cache_{code_hash}")
                    try:
                        shutil.copy2(output_bin, cached_path)
                        self._compile_cache[code_hash] = cached_path
                    except Exception as e:
                        logger.warning(f"Failed to update cache: {e}")

            return True

        except subprocess.TimeoutExpired:
            logger.error("Compilation timed out")
            return False
        except Exception as e:
            logger.error(f"Compilation error: {e}")
            return False
