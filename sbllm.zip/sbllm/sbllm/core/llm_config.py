
import os
import logging
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

def load_keys(env_var):
    val = os.getenv(env_var, "")
    return [k.strip() for k in val.split(",") if k.strip()]

# Load API Keys
openai_api_keys = load_keys("OPENAI_API_KEYS")
llama_api_keys = load_keys("LLAMA_API_KEYS")
gemini_api_keys = load_keys("GEMINI_API_KEYS")
deepseek_api_keys = load_keys("DEEPSEEK_API_KEYS")

def get_api_keys(model_name):
    """
    Get the list of API keys for a specific model.
    """
    keys_map = {
        'gemini': gemini_api_keys,
        'deepseek': deepseek_api_keys,
        'codellama': llama_api_keys
    }
    # Default to OpenAI keys if not specific match found, or if model is 'gpt4' etc.
    # The original code prioritized specific keys, then fell back to openai_api_keys
    return keys_map.get(model_name, openai_api_keys)

def get_model_id(model_name):
    """
    Map friendly model name to actual model identifier.
    Prioritizes environment variables.
    """
    model_id_map = {
        'gemini': os.getenv("GEMINI_MODEL_NAME", "gemini-pro"),
        'deepseek': os.getenv("DEEPSEEK_MODEL_NAME", "deepseek-chat"),
        'codellama': os.getenv("LLAMA_MODEL_NAME", "codellama/CodeLlama-34b-Instruct-hf")
    }
    # Default fallback
    return model_id_map.get(model_name, "gpt-3.5-turbo-0613")
