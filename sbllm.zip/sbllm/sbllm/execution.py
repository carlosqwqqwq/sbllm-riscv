import os
import re
import tokenize
from io import StringIO
import time
import jsonlines 
import subprocess
import logging
from utils.qemu_evaluator import QEMURISCVEvaluator
import multiprocessing
import shutil
import tempfile
import traceback
from tqdm import tqdm
from utils.code_utils import remove_comments_and_docstrings
from utils.statistics_utils import calculate_statistics, write_yaml

logger = logging.getLogger(__name__)

def evaluate_single_item_qemu(args):
    try:
        item, cfg, reference_data_item = args
        
        # Ensure parent temp directory exists
        parent_temp_dir = os.path.join(cfg.output_path, cfg.mode, 'qemu_temp')
        os.makedirs(parent_temp_dir, exist_ok=True)
        
        # Use TemporaryDirectory for automatic cleanup
        with tempfile.TemporaryDirectory(dir=parent_temp_dir) as worker_temp_dir:
            qemu_evaluator = QEMURISCVEvaluator(
                qemu_path=cfg.qemu_path,
                riscv_gcc_toolchain_path=cfg.riscv_gcc_toolchain_path,
                temp_dir=worker_temp_dir
            )
        
            original_code = item['slow_code_col']
            candidate_codes = item['model_generated_potentially_faster_code_col']
            
            if not isinstance(candidate_codes, list):
                candidate_codes = [candidate_codes]
            
            # Get reference code/input
            ref_code = reference_data_item.get('code', original_code)
            ref_input = reference_data_item.get('input', '')
            
            # Evaluate original
            original_bin = os.path.join(worker_temp_dir, 'original.bin')
            if qemu_evaluator.compile_to_riscv_binary(original_code, original_bin):
                original_time, original_size, original_correct, original_output = qemu_evaluator.run_and_measure(
                    original_bin, ref_input, num_runs=5
                )
            else:
                original_time, original_size, original_correct, original_output = 99999.0, 0, False, None
            
            # Evaluate reference (using original output as target if available)
            reference_bin = os.path.join(worker_temp_dir, 'reference.bin')
            if qemu_evaluator.compile_to_riscv_binary(ref_code, reference_bin):
                reference_time, reference_size, reference_correct, reference_output = qemu_evaluator.run_and_measure(
                    reference_bin, ref_input, num_runs=5, reference_output=original_output
                )
            else:
                reference_time, reference_size, reference_correct, reference_output = 99999.0, 0, False, None
            
            standard_output = original_output or reference_output
            
            # Evaluate candidates
            best_candidate_time = original_time
            best_candidate_size = original_size
            best_candidate_idx = -1
            best_candidate_acc = 0
            best_candidate_score = -float('inf')  # Composite score
            candidate_results = []
            
            for idx, candidate_code in enumerate(candidate_codes[:10]):
                candidate_bin = os.path.join(worker_temp_dir, f'candidate_{idx}.bin')
                if qemu_evaluator.compile_to_riscv_binary(candidate_code, candidate_bin):
                    candidate_time, candidate_size, candidate_correct, candidate_output = qemu_evaluator.run_and_measure(
                        candidate_bin, ref_input, num_runs=5, reference_output=standard_output
                    )
                            
                    # Calculate OPT = 1 - new_time / old_time
                    opt_ratio = 1 - candidate_time / original_time if original_time > 0 else 0
                    # Calculate size reduction ratio
                    size_reduction = (original_size - candidate_size) / original_size if original_size > 0 else 0
                    # Composite score: alpha * OPT + beta * size_reduction (alpha=0.7, beta=0.3)
                    composite_score = 0.7 * opt_ratio + 0.3 * size_reduction
                    
                    candidate_results.append({
                        'idx': idx,
                        'time': candidate_time,
                        'size': candidate_size,
                        'correct': candidate_correct,
                        'code': candidate_code,
                        'output': candidate_output,
                        'opt_ratio': opt_ratio,
                        'size_reduction': size_reduction,
                        'composite_score': composite_score
                    })
                    # Select best based on composite score (only if correct)
                    if candidate_correct and composite_score > best_candidate_score:
                        best_candidate_score = composite_score
                        best_candidate_time = candidate_time
                        best_candidate_size = candidate_size
                        best_candidate_idx = idx
                        best_candidate_acc = 1
                else:
                    # Get last compile error for debugging
                    compile_error = getattr(qemu_evaluator, 'last_compile_error', 'Compilation failed')
                    candidate_results.append({
                        'idx': idx,
                        'time': 99999.0,
                        'size': 0,
                        'correct': False,
                        'code': candidate_code,
                        'error': compile_error,  # Record compile error
                        'opt_ratio': 0,
                        'size_reduction': 0,
                        'composite_score': -float('inf')
                    })

            # Best candidate code
            if best_candidate_idx >= 0:
                best_candidate_code = candidate_codes[best_candidate_idx]
            else:
                best_candidate_code = original_code
            
            # Exec item with query tracking
            exec_item = {
                'query_idx': reference_data_item.get('idx', reference_data_item.get('id', 'Unknown')),
                'query_desc': reference_data_item.get('description', ''),
                'code_v0_no_empty_lines': original_code,
                'code_v1_no_empty_lines': ref_code,
                'input_time_mean': original_time,
                'input_acc': 1 if original_correct else 0,
                'reference_time_mean': reference_time,
                'reference_acc': 1 if reference_correct else 0,
                'model_generated_potentially_faster_code_col': best_candidate_code,
                'model_generated_potentially_faster_code_col_acc': best_candidate_acc,
                'model_generated_potentially_faster_code_col_time_mean': best_candidate_time,
            }
            
            for result in candidate_results:
                ridx = result['idx']
                if ridx < 5:
                    exec_item[f'model_generated_potentially_faster_code_col_{ridx}'] = result['code']
                    exec_item[f'model_generated_potentially_faster_code_col_{ridx}_acc'] = 1 if result['correct'] else 0
                    exec_item[f'model_generated_potentially_faster_code_col_{ridx}_time_mean'] = result['time']
            
            return exec_item
    except Exception as e:
        logger.error(f"Error in evaluate_single_item_qemu: {e}")
        logger.error(traceback.format_exc())
        return None

def testing_and_reporting(cfg):
    # Check for RISC-V Mode
    is_riscv_mode = hasattr(cfg, 'riscv_mode') and cfg.riscv_mode or cfg.lang == 'riscv' or (cfg.mode and 'riscv' in cfg.mode.lower())
    
    if is_riscv_mode and hasattr(cfg, 'qemu_path') and hasattr(cfg, 'riscv_gcc_toolchain_path'):
        # Use QEMU RISC-V Evaluator
        logger.info('Using QEMU RISC-V Evaluator...')
        _testing_and_reporting_qemu(cfg)
    else:
        # Use Legacy Evaluator
        logger.info('Using Original Evaluator...')
        _testing_and_reporting_original(cfg)


def _testing_and_reporting_qemu(cfg):
    """Execution with QEMU Evaluator"""
    logger.info('Mapping code and inputs...')
    reference_data = {}
    # Determine test data path
    if hasattr(cfg, 'baseline_data_path') and cfg.baseline_data_path:
        test_data_path = cfg.baseline_data_path
    else:
        test_data_path = "../processed_data/{}/test.jsonl".format(cfg.lang)
    
    if not os.path.exists(test_data_path):
        logger.error(f"Test data file not found: {test_data_path}")
        raise FileNotFoundError(f"Test data file not found: {test_data_path}")
    
    # helper for cleaning key
    def clean_key(code):
        return remove_comments_and_docstrings(code, cfg.lang).strip()

    with jsonlines.open(test_data_path) as f:
        for obj in f:
            # Map cleaned code to full object (input, code, output etc)
            key_code = clean_key(obj['code_v0_no_empty_lines'])
            reference_data[key_code] = obj

    print('Processing...')
    processed = []
    queries_path = os.path.join(cfg.output_path, cfg.mode, 'tmp_queries_{}.jsonl'.format(cfg.model_name+'test'))
    if not os.path.exists(queries_path):
        logger.warning(f"Warning: Queries file not found ({queries_path}), skipping evaluation.")
        # Create empty report
        report_path = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        with jsonlines.open(report_path, 'w') as f:
            pass  # Empty file
        return
    
    with jsonlines.open(queries_path) as f:
        for i in f:
            query_key = i.get('query', '')
            if not query_key and 'code_v0_no_empty_lines' in i:
                query_key = i['code_v0_no_empty_lines']
            
            # Try to match
            matched_ref = None
            if query_key in reference_data:
                matched_ref = reference_data[query_key]
            else:
                 # Try cleaning
                 cleaned_q = clean_key(query_key)
                 if cleaned_q in reference_data:
                     matched_ref = reference_data[cleaned_q]
                 else:
                     # Fallback: try to find by idx
                     query_idx = str(i.get('idx', ''))
                     for key, ref in reference_data.items():
                         if str(ref.get('idx', '')) == query_idx:
                             matched_ref = ref
                             break
            
            if matched_ref:
                processed.append({
                    'slow_code_col': matched_ref.get('code_v0_no_empty_lines', query_key),
                    'model_generated_potentially_faster_code_col': i.get('prediction', []),
                    'matched_ref': matched_ref
                })

    print(f'{len(processed)} queries matched reference data')
    
    if len(processed) == 0:
        print("No results to evaluate")
        # Create empty report
        report_path = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        with jsonlines.open(report_path, 'w') as f:
            pass
        return

    # Prepare args for parallel execution
    pool_args = []
    for item in processed:
        ref_data_item = item.get('matched_ref', {})
        pool_args.append((item, cfg, ref_data_item))

    print(f"Using {getattr(cfg, 'process_number', 8)} processes for parallel evaluation...")
    execution_data = []
    success_count = 0
    fail_count = 0
    
    # Detailed Failure Tracking
    failure_stats = {
        'Compilation Failed': 0,
        'Timeout': 0, 
        'Wrong Output': 0,
        'Runtime Error': 0,
        'Other': 0
    }

    start_time = time.time()
    
    if len(pool_args) > 0:
        with multiprocessing.Pool(getattr(cfg, 'process_number', 8)) as pool:
            with tqdm(total=len(pool_args), desc="Evaluation Progress", mininterval=0.5) as pbar:
                for result in pool.imap_unordered(evaluate_single_item_qemu, pool_args):
                    if result:
                        execution_data.append(result)
                        best_acc = result.get('model_generated_potentially_faster_code_col_acc', 0)
                        
                        if best_acc == 1:
                            success_count += 1
                        else:
                            fail_count += 1
                            # Categorize failure for top-1 candidate (simplified)
                            # In reality, different candidates have different errors. 
                            # We check the BEST candidate's error or the first one.
                            # For summary, let's look at the first candidate's result in the item if available,
                            # but `result` dict structure here is the summarized `exec_item`.
                            # We can't easily extract exact error type from summarized `exec_item` 
                            # without passing it through. Let's rely on a rough heuristic or leave detailed breakdown for later.
                            # Actually, we can assume 'compile_error' might be passed if we modified `evaluate_single_item_qemu` slightly,
                            # but for now let's just count generic failures. 
                            pass 
                    else:
                        fail_count += 1
                        failure_stats['Other'] += 1
                    
                    pbar.set_postfix(success=success_count, fail=fail_count)
                    pbar.update(1)
    else:
        print("No items to process.")

    total_time = time.time() - start_time

    # --- Detailed Evaluation Summary ---
    print("\n" + "="*70)
    print("  详细评估结果 (Detailed Evaluation Results)")
    print("="*70)
    print("="*70)
    total_opt_count = 0
    # total_speedup_sum = 0.0 # No longer needed
    max_speedup_overall = 0.0
    for idx, result in enumerate(execution_data):
        # Extract query ID and description
        query_idx = result.get('query_idx', idx+1)
        query_desc = result.get('query_desc', '')
        # Fix: use '\n' for split, not '\\n'
        code_preview = result.get('code_v0_no_empty_lines', '').split('\n')[0][:40]
        original_time = result.get('input_time_mean', 99999)
        best_time = result.get('model_generated_potentially_faster_code_col_time_mean', 99999)
        best_acc = result.get('model_generated_potentially_faster_code_col_acc', 0)
        
        # Count successful candidates
        cand_success_count = 0
        for i in range(5):
            if result.get(f'model_generated_potentially_faster_code_col_{i}_acc', 0) == 1:
                cand_success_count += 1
        
        # Calculate best speedup for this query
        if original_time > 0 and best_time < 99999:
            speedup = original_time / best_time
        else:
            speedup = 0.0
        
        # Collect speedups for all candidates
        candidate_speedups = []
        for i in range(5):
             cand_time = result.get(f'model_generated_potentially_faster_code_col_{i}_time_mean', 99999)
             if result.get(f'model_generated_potentially_faster_code_col_{i}_acc', 0) == 1 and cand_time < 99999 and original_time > 0:
                 sp = original_time / cand_time
                 candidate_speedups.append(f"{sp:.2f}x")
             else:
                 candidate_speedups.append("-")

        if best_acc == 1 and speedup > 1.0:
            status = "✓ OPT"
            total_opt_count += 1
            if speedup > max_speedup_overall:
                max_speedup_overall = speedup
        elif best_acc == 1:
            status = "✓ OK (No Speedup)"
        else:
            status = "✗ Fail"
        
        # Display with query ID
        desc_display = f" ({query_desc})" if query_desc else ""
        print(f"  [ID:{query_idx}] {code_preview}...{desc_display}")
        print(f"      成功候选: {cand_success_count}/5 | 最佳加速比: {speedup:.2f}x (vs Original) | 状态: {status}")
        print(f"      候选详情: {', '.join(candidate_speedups)}")
        print("-"*70)
    
    # Summary statistics
    # avg_speedup = total_speedup_sum / max(total_opt_count, 1) # Removed as per request
    print(f"\n  汇总统计:")
    print(f"    - 总查询数: {len(execution_data)}")
    print(f"    - 成功优化: {total_opt_count}/{len(execution_data)} ({100*total_opt_count/max(len(execution_data),1):.1f}%)")
    print(f"    - 最高加速比 (全局): {max_speedup_overall:.2f}x (vs Original)")
    print(f"    - 评估耗时: {total_time:.2f}s")
    print("="*70 + "\n")
    # --- End Detailed Summary ---

    # Save Report
    report_path = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with jsonlines.open(report_path, 'w') as f:
        f.write_all(execution_data)
    
    # Calculate Statistics
    calculate_statistics(execution_data, cfg)


def _testing_and_reporting_original(cfg):
    """Original Evaluation System"""
    print('Mapping...')
    input_code_map = {}
    with jsonlines.open("../processed_data/{}/test.jsonl".format(cfg.lang)) as f:
        for obj in f:
            input_code_map[remove_comments_and_docstrings(obj['code_v0_no_empty_lines'], cfg.lang)] = obj.get('input', '')

    print('Processing...')
    processed = []
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'tmp_queries_{}.jsonl'.format(cfg.model_name+'test'))) as f:
        for i in f:
            processed.append({'slow_code_col':input_code_map[i['query']], 'model_generated_potentially_faster_code_col':i['prediction']})
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.jsonl'.format(cfg.model_name+'test')),'w') as f:
        f.write_all(processed)

    data = {}
    data['language'] = cfg.lang
    data['model_generated_outputs_path'] = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.jsonl'.format(cfg.model_name+'test'))
    data['inputs_outputs_basepath'] = cfg.test_case_path
    data['reference_file_path'] = "../processed_data/{}/test.jsonl".format(cfg.lang)
    data['output_report_file_path'] = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
    data['preprocessed_output_file'] = "../processed_data/{}/processed_time.reports".format(cfg.lang)
    data['num_problems_to_evaluate'] = -1
    data['num_trials'] = 8
    data['ignore_first_k'] = 1
    data['max_time_per_run'] = 10
    data['temp_dir'] = "../processed_data/{}/generated_tmp".format(cfg.lang)
    data['model_generated_potentially_faster_code_col'] = "model_generated_potentially_faster_code_col"
    data['slow_code_col'] = "slow_code_col"
    data['reference_code_col'] = "target"
    data['reference_input_col'] = "input"
    data['is_prompt_based'] = False
    data['run_reference'] = True
    data['run_input'] = True
    data['cpu_number'] = 1
    data['process_number'] = int(cfg.process_number)
    write_yaml(data, os.path.join(cfg.output_path, cfg.mode, 'eval_config.yaml'))

    error_file = open(os.path.join(cfg.output_path, cfg.mode, "stderr.txt"), "wb")
    out_file = open(os.path.join(cfg.output_path, cfg.mode, "output.txt"),"wb")
    print("Testing...")
    
    if not os.path.exists(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))):
        cmd = 'cd ../pie; python src/codenet_eval/run_eval_feedback.py --eval_config {}'.format(os.path.join(cfg.output_path, cfg.mode, 'eval_config.yaml'))
        child = subprocess.Popen(cmd, shell=True, stdout=out_file, stderr=error_file, bufsize=-1, start_new_session=True)
        while True:
            Flag = child.poll()
            if Flag == 0:
                error_file.close()
                out_file.close()
                break
            else:
                time.sleep(10)
    
    execution_data = []
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))) as f:
        for i in f:
            execution_data.append(i)
    
    calculate_statistics(execution_data, cfg)


