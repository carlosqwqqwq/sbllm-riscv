# RISC-V 功能测试教程

## 📖 简介

本教程将指导你如何使用 `test_riscv.sh` 脚本快速测试 RISC-V 优化框架的基本功能。这个测试脚本会自动创建测试数据、运行环境验证、执行一次简化的优化流程，并验证结果。

## 🎯 测试目标

测试脚本将验证以下功能：

1. ✅ **环境配置**：QEMU 和 RISC-V GCC 工具链是否正确配置
2. ✅ **数据准备**：测试数据和训练数据格式是否正确
3. ✅ **代码生成**：LLM 是否能生成优化候选代码
4. ✅ **代码评估**：QEMU 评估器是否能正确编译和运行代码
5. ✅ **结果输出**：评估报告是否正确生成

## 📋 前置要求

### 1. 系统要求

- Linux 系统（推荐 Ubuntu 20.04+）
- Python 3.9.12+
- QEMU（qemu-riscv64）
- RISC-V GCC 工具链

### 2. 安装依赖

```bash
# 安装 Python 依赖
cd sbllm
pip install -r requirement.txt

# 安装 QEMU（Ubuntu/Debian）
sudo apt-get update
sudo apt-get install qemu-user-riscv64

# 验证 QEMU 安装
qemu-riscv64 --version
```

### 3. 配置 API 密钥

编辑 `sbllm/sbllm/evol_query.py`，填入你的 API 密钥：

```python
# 默认使用 DeepSeek，确保配置此项
deepseek_api_keys = [
    "your-deepseek-api-key",
]

# 可选：其他模型的 API 密钥
openai_api_keys = ['your-openai-api-key']
gemini_api_keys = ["your-gemini-api-key"]
# ... 其他 API 密钥
```

**重要**：测试脚本默认使用 `deepseek` 模型，必须配置 `deepseek_api_keys`。

## 🚀 快速开始

### 步骤 1: 进入脚本目录

```bash
cd sbllm/sbllm
```

### 步骤 2: 运行测试脚本

```bash
bash test_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu
```

**注意**：
- 请根据你的实际安装路径修改 `--qemu_path` 和 `--riscv_gcc_toolchain_path` 参数
- 测试脚本默认使用 `deepseek` 模型，确保已在 `evol_query.py` 中配置 DeepSeek API 密钥

### 步骤 3: 查看测试结果

测试完成后，查看评估报告：

```bash
cat test_output_riscv/riscv/riscv_optimization/0/test_execution_0.report
```

## 📝 详细使用说明

### 基本用法

```bash
bash test_riscv.sh \
    --qemu_path <QEMU路径> \
    --riscv_gcc_toolchain_path <工具链路径>
```

### 使用不同模型

```bash
# 默认使用 DeepSeek（无需指定）
bash test_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu

# 使用 Gemini
bash test_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu \
    --model_name gemini

# 使用 GPT-4
bash test_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu \
    --model_name gpt4

# 使用 ChatGPT
bash test_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu \
    --model_name chatgpt
```

### 查看帮助

```bash
bash test_riscv.sh --help
```

## 🔍 测试流程详解

### 步骤 1: 环境验证

测试脚本首先会运行 `validate_riscv_setup.py` 验证环境配置：

- ✅ 检查 QEMU 可执行文件
- ✅ 检查 RISC-V GCC 工具链
- ✅ 检查 Python 依赖包
- ✅ 检查 API 密钥配置

**如果验证失败**：
- 检查 QEMU 和工具链路径是否正确
- 确认所有依赖已安装
- 检查 API 密钥是否已配置

### 步骤 2: 创建测试数据

脚本会自动创建以下测试数据：

1. **test.jsonl**：包含一个简单的 RISC-V 汇编函数（数组求和）
   - 包含代码注释，说明优化方向
   - 包含测试输入数据

2. **train.jsonl**：简化的训练数据（知识库）
   - 包含一个优化示例
   - 用于测试知识库检索功能

**测试数据位置**：`./test_data_riscv/`

### 步骤 3: 初始化结果

运行 `initial.py` 初始化结果文件结构。

### 步骤 4: 运行优化迭代

执行一次简化的优化流程：

1. **生成优化候选**（`evol_query.py`）
   - 分析代码注释
   - 生成 3 个优化候选（快速测试）

2. **评估候选代码**（`evaluate.py`）
   - 使用 QEMU 编译和运行代码
   - 评估功能正确性和性能

### 步骤 5: 验证结果

检查评估报告是否成功生成。

## 📊 测试输出说明

### 成功输出示例

```
============================================================
        RISC-V 优化框架功能测试
============================================================

[步骤 1/5] 环境验证
------------------------------------------------------------
✓ QEMU: /usr/bin/qemu-riscv64
✓ 工具链工具: riscv64-unknown-linux-gnu-gcc
✓ 所有检查通过！环境配置正确。

[步骤 2/5] 创建测试数据
------------------------------------------------------------
✓ 测试数据已创建
  - 测试数据: ./test_data_riscv/test.jsonl
  - 训练数据: ./test_data_riscv/train.jsonl

[步骤 3/5] 初始化结果
------------------------------------------------------------
...

[步骤 4/5] 运行优化迭代（快速测试）
------------------------------------------------------------
生成优化候选...
评估候选代码...
✓ 优化迭代完成

[步骤 5/5] 验证结果
------------------------------------------------------------
✓ 找到评估报告
✓ 测试完成！
```

### 输出文件结构

```
test_output_riscv/
└── riscv/
    └── riscv_optimization/
        └── 0/
            ├── prediction_0.jsonl      # 生成的候选代码
            └── test_execution_0.report # 评估报告
```

## 🔧 故障排除

### 问题 1: 环境验证失败

**错误信息**：
```
✗ QEMU: /usr/bin/qemu-riscv64 (文件不存在)
```

**解决方案**：
```bash
# 检查 QEMU 是否安装
which qemu-riscv64

# 如果未安装，安装 QEMU
sudo apt-get install qemu-user-riscv64

# 使用实际路径
bash test_riscv.sh \
    --qemu_path $(which qemu-riscv64) \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu
```

### 问题 2: API 密钥未配置

**错误信息**：
```
⚠ 检测到占位符 API 密钥
```

**解决方案**：
1. 编辑 `sbllm/sbllm/evol_query.py`
2. 替换占位符 API 密钥为真实密钥
3. 重新运行测试

### 问题 3: 代码生成失败

**错误信息**：
```
生成候选失败
```

**可能原因**：
- API 密钥无效或配额不足
- 网络连接问题
- LLM 服务不可用

**解决方案**：
- 检查 API 密钥是否有效（默认使用 DeepSeek，确保 `deepseek_api_keys` 已配置）
- 检查网络连接
- 尝试使用其他模型（`--model_name gemini` 或 `--model_name chatgpt`）

### 问题 4: 编译失败

**错误信息**：
```
Assembly failed: error: invalid instruction
```

**解决方案**：
- 检查测试数据中的代码格式
- 确认是有效的 RISC-V 汇编代码
- 查看详细错误日志

### 问题 5: 评估报告未生成

**可能原因**：
- 评估过程中出现错误
- 输出目录权限问题

**解决方案**：
```bash
# 检查输出目录权限
ls -la test_output_riscv/

# 手动检查评估日志
cat test_output_riscv/riscv/riscv_optimization/0/*.log
```

## 📈 测试结果解读

### 评估报告格式

评估报告（`test_execution_*.report`）包含以下信息：

```json
{
    "code_v0_no_empty_lines": "原始代码",
    "input_time_mean": 1.23,
    "model_generated_potentially_faster_code_col_0": "候选代码 0",
    "model_generated_potentially_faster_code_col_0_acc": 1,
    "model_generated_potentially_faster_code_col_0_time_mean": 0.85
}
```

### 关键指标

- **acc**：功能正确性（1 = 正确，0 = 错误）
- **time_mean**：平均执行时间（秒）
- **speedup_ratio**：加速比（正值表示性能提升）

### 成功标准

测试成功的标准：
- ✅ 至少生成 1 个候选代码
- ✅ 至少 1 个候选代码功能正确（acc = 1）
- ✅ 评估报告成功生成

## 🎓 进阶使用

### 自定义测试数据

你可以修改 `test_riscv.sh` 中的测试数据，使用你自己的 RISC-V 代码：

```bash
# 编辑脚本，修改测试数据部分
vim test_riscv.sh
```

### 运行完整测试

测试脚本只运行一次迭代。要运行完整的优化流程，使用：

```bash
bash run_riscv.sh \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu
```

### 调试模式

如果测试失败，可以手动运行各个步骤进行调试：

```bash
# 1. 环境验证
python3 validate_riscv_setup.py \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu

# 2. 生成候选
python3 evol_query.py \
    --mode riscv_optimization \
    --model_name chatgpt \
    --lang riscv \
    --generation_path ../test_output_riscv \
    --baseline_data_path test_data_riscv/test.jsonl \
    --iteration 0 \
    --generation_number 3 \
    --riscv_mode

# 3. 评估
python3 evaluate.py \
    --mode riscv_optimization \
    --lang riscv \
    --output_path ../test_output_riscv/riscv \
    --model_name chatgpt \
    --qemu_path /usr/bin/qemu-riscv64 \
    --riscv_gcc_toolchain_path /opt/riscv64-unknown-linux-gnu \
    --test_case_path test_data_riscv/test_cases \
    --process_number 2 \
    --riscv_mode
```

## 📚 相关文档

- **完整使用手册**：`README-RISCV.md`
- **环境验证脚本**：`validate_riscv_setup.py`
- **完整运行脚本**：`run_riscv.sh`

## 💡 提示

1. **首次运行**：建议先运行测试脚本验证环境配置
2. **快速验证**：测试脚本使用简化的配置，运行时间约 2-5 分钟
3. **生产使用**：测试通过后，使用 `run_riscv.sh` 进行完整的优化流程
4. **模型选择**：如果某个模型失败，尝试使用其他模型（`--model_name gemini`）

## ❓ 常见问题

**Q: 测试脚本运行多长时间？**
A: 通常 2-5 分钟，取决于 LLM API 响应速度和系统性能。

**Q: 测试数据会被保存吗？**
A: 是的，测试数据保存在 `test_data_riscv/` 目录，输出保存在 `test_output_riscv/` 目录。

**Q: 可以删除测试数据吗？**
A: 可以，测试数据会在每次运行时重新创建。

**Q: 测试失败怎么办？**
A: 查看错误信息，参考故障排除部分，或查看详细日志。

---

**祝你测试顺利！** 🎉

