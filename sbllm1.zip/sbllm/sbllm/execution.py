import os
import re
import tokenize
from io import StringIO
import yaml
import time
import jsonlines 
import subprocess
import logging
from qemu_evaluator import QEMURISCVEvaluator

logger = logging.getLogger(__name__)


def write_yaml(data, file_path):
    with open(file=file_path,mode='w',encoding='utf8') as f:
        yaml.dump(data,f)


def remove_comments_and_docstrings(source,lang):
    if lang in ['python']:
        """
        Returns 'source' minus comments and docstrings.
        """
        io_obj = StringIO(source)
        out = ""
        prev_toktype = tokenize.INDENT
        last_lineno = -1
        last_col = 0
        for tok in tokenize.generate_tokens(io_obj.readline):
            token_type = tok[0]
            token_string = tok[1]
            start_line, start_col = tok[2]
            end_line, end_col = tok[3]
            ltext = tok[4]
            if start_line > last_lineno:
                last_col = 0
            if start_col > last_col:
                out += (" " * (start_col - last_col))
            # Remove comments:
            if token_type == tokenize.COMMENT:
                pass
            # This series of conditionals removes docstrings:
            elif token_type == tokenize.STRING:
                if prev_toktype != tokenize.INDENT:
            # This is likely a docstring; double-check we're not inside an operator:
                    if prev_toktype != tokenize.NEWLINE:
                        if start_col > 0:
                            out += token_string
            else:
                out += token_string
            prev_toktype = token_type
            last_col = end_col
            last_lineno = end_line
        temp=[]
        for x in out.split('\n'):
            if x.strip()!="":
                temp.append(x)
        return '\n'.join(temp)
    elif lang in ['ruby']:
        return source
    else:
        def replacer(match):
            s = match.group(0)
            if s.startswith('/'):
                return " " # note: a space and not an empty string
            else:
                return s
        pattern = re.compile(
            r'//.*?$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"',
            re.DOTALL | re.MULTILINE
        )
        temp=[]
        for x in re.sub(pattern, replacer, source).split('\n'):
            if x.strip()!="":
                temp.append(x)
        return '\n'.join(temp)




def testing_and_reporting(cfg):
    # 检查是否为 RISC-V 模式
    is_riscv_mode = hasattr(cfg, 'riscv_mode') and cfg.riscv_mode or cfg.lang == 'riscv' or 'riscv' in cfg.mode.lower()
    
    if is_riscv_mode and hasattr(cfg, 'qemu_path') and hasattr(cfg, 'riscv_gcc_toolchain_path'):
        # 使用 QEMU 评估器
        print('Using QEMU RISC-V evaluator...')
        _testing_and_reporting_qemu(cfg)
    else:
        # 使用原有的评估系统
        print('Using original evaluation system...')
        _testing_and_reporting_original(cfg)


def _testing_and_reporting_qemu(cfg):
    """使用 QEMU 评估器进行评估"""
    print('mapping......')
    input_code_map = {}
    test_data_path = "../processed_data/{}/test.jsonl".format(cfg.lang)
    if not os.path.exists(test_data_path):
        raise FileNotFoundError(f"Test data file not found: {test_data_path}")
    with jsonlines.open(test_data_path) as f:
        for obj in f:
            input_code_map[remove_comments_and_docstrings(obj['code_v0_no_empty_lines'], cfg.lang)] = obj['input']

    print('processing......')
    processed = []
    queries_path = os.path.join(cfg.output_path, cfg.mode, 'tmp_queries_{}.jsonl'.format(cfg.model_name+'test'))
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")
    with jsonlines.open(queries_path) as f:
        for i in f:
            query_key = i.get('query', '')
            if query_key in input_code_map:
                processed.append({'slow_code_col':input_code_map[query_key], 'model_generated_potentially_faster_code_col':i.get('prediction', [])})
            else:
                logger.warning(f"Query key not found in input_code_map: {query_key[:50]}...")
    
    # 初始化 QEMU 评估器
    qemu_evaluator = QEMURISCVEvaluator(
        qemu_path=cfg.qemu_path,
        riscv_gcc_toolchain_path=cfg.riscv_gcc_toolchain_path,
        temp_dir=os.path.join(cfg.output_path, cfg.mode, 'qemu_temp')
    )
    
    # 创建临时目录
    os.makedirs(qemu_evaluator.temp_dir, exist_ok=True)
    
    print("testing with QEMU......")
    execution_data = []
    
    # 读取参考数据
    reference_data = {}
    with jsonlines.open("../processed_data/{}/test.jsonl".format(cfg.lang)) as f:
        for obj in f:
            code_key = remove_comments_and_docstrings(obj['code_v0_no_empty_lines'], cfg.lang)
            reference_data[code_key] = {
                'code': obj.get('target', obj.get('code_v1_no_empty_lines', '')),
                'input': obj.get('input', '')
            }
    
    # 评估每个候选代码
    for item in processed:
        original_code = item['slow_code_col']
        candidate_codes = item['model_generated_potentially_faster_code_col']
        
        if not isinstance(candidate_codes, list):
            candidate_codes = [candidate_codes]
        
        # 获取参考代码
        ref_code = reference_data.get(original_code, {}).get('code', original_code)
        ref_input = reference_data.get(original_code, {}).get('input', '')
        
        # 评估原始代码
        original_bin = os.path.join(qemu_evaluator.temp_dir, 'original.bin')
        if qemu_evaluator.compile_to_riscv_binary(original_code, original_bin):
            original_time, original_size, original_correct, original_output = qemu_evaluator.run_and_measure(
                original_bin, ref_input, num_runs=5
            )
        else:
            original_time, original_size, original_correct, original_output = 99999.0, 0, False, None
        
        # 评估参考代码（使用原始代码的输出作为参考）
        reference_bin = os.path.join(qemu_evaluator.temp_dir, 'reference.bin')
        if qemu_evaluator.compile_to_riscv_binary(ref_code, reference_bin):
            reference_time, reference_size, reference_correct, reference_output = qemu_evaluator.run_and_measure(
                reference_bin, ref_input, num_runs=5, reference_output=original_output
            )
        else:
            reference_time, reference_size, reference_correct, reference_output = 99999.0, 0, False, None
        
        # 使用参考代码的输出作为标准输出（如果原始代码输出不可用）
        standard_output = original_output or reference_output
        
        # 评估候选代码
        best_candidate_time = original_time
        best_candidate_idx = -1
        best_candidate_acc = 0
        candidate_results = []  # 存储所有候选的评估结果
        
        for idx, candidate_code in enumerate(candidate_codes[:5]):  # 最多评估5个候选
            candidate_bin = os.path.join(qemu_evaluator.temp_dir, f'candidate_{idx}.bin')
            if qemu_evaluator.compile_to_riscv_binary(candidate_code, candidate_bin):
                # 使用标准输出进行功能正确性检查
                candidate_time, candidate_size, candidate_correct, candidate_output = qemu_evaluator.run_and_measure(
                    candidate_bin, ref_input, num_runs=5, reference_output=standard_output
                )
                candidate_results.append({
                    'idx': idx,
                    'time': candidate_time,
                    'correct': candidate_correct,
                    'code': candidate_code,
                    'output': candidate_output
                })
                
                # 优先选择正确且更快的候选
                if candidate_correct:
                    if best_candidate_idx == -1 or candidate_time < best_candidate_time:
                        best_candidate_time = candidate_time
                        best_candidate_idx = idx
                        best_candidate_acc = 1
            else:
                # 编译失败，记录但标记为不正确
                candidate_results.append({
                    'idx': idx,
                    'time': 99999.0,
                    'correct': False,
                    'code': candidate_code
                })
        
        # 构建执行报告
        if len(candidate_codes) == 0:
            # 如果没有候选代码，使用原始代码
            best_candidate_code = original_code
            best_candidate_time = original_time
            best_candidate_acc = 0
        else:
            best_candidate_code = candidate_codes[best_candidate_idx] if best_candidate_idx >= 0 else candidate_codes[0]
        
        exec_item = {
            'code_v0_no_empty_lines': original_code,
            'code_v1_no_empty_lines': ref_code,
            'input_time_mean': original_time,
            'input_time_std': 0.0,
            'reference_time_mean': reference_time,
            'reference_time_std': 0.0,
            'model_generated_potentially_faster_code_col': best_candidate_code,
            'model_generated_potentially_faster_code_col_acc': best_candidate_acc,
            'model_generated_potentially_faster_code_col_time_mean': best_candidate_time,
            'model_generated_potentially_faster_code_col_time_std': 0.0,
        }
        
        # 为每个候选添加详细信息（使用之前评估的结果）
        for result in candidate_results:
            idx = result['idx']
            if idx < 5:  # 只记录前5个
                exec_item[f'model_generated_potentially_faster_code_col_{idx}'] = result['code']
                exec_item[f'model_generated_potentially_faster_code_col_{idx}_acc'] = 1 if result['correct'] else 0
                exec_item[f'model_generated_potentially_faster_code_col_{idx}_time_mean'] = result['time']
                exec_item[f'model_generated_potentially_faster_code_col_{idx}_time_std'] = 0.0
        
        execution_data.append(exec_item)
    
    # 保存执行报告
    report_path = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
    with jsonlines.open(report_path, 'w') as f:
        f.write_all(execution_data)
    
    # 计算统计信息
    _calculate_statistics(execution_data, cfg)


def _testing_and_reporting_original(cfg):
    """使用原有的评估系统"""
    print('mapping......')
    input_code_map = {}
    with jsonlines.open("../processed_data/{}/test.jsonl".format(cfg.lang)) as f:
        for obj in f:
            input_code_map[remove_comments_and_docstrings(obj['code_v0_no_empty_lines'], cfg.lang)] = obj['input']

    print('processing......')
    processed = []
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'tmp_queries_{}.jsonl'.format(cfg.model_name+'test'))) as f:
        for i in f:
            processed.append({'slow_code_col':input_code_map[i['query']], 'model_generated_potentially_faster_code_col':i['prediction']})
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.jsonl'.format(cfg.model_name+'test')),'w') as f:
        f.write_all(processed)

    data = {}
    data['language'] = cfg.lang
    data['model_generated_outputs_path'] = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.jsonl'.format(cfg.model_name+'test'))
    data['inputs_outputs_basepath'] = cfg.test_case_path
    data['reference_file_path'] = "../processed_data/{}/test.jsonl".format(cfg.lang)
    data['output_report_file_path'] = os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))
    data['preprocessed_output_file'] = "../processed_data/{}/processed_time.reports".format(cfg.lang)
    data['num_problems_to_evaluate'] = -1
    data['num_trials'] = 8
    data['ignore_first_k'] = 1
    data['max_time_per_run'] = 10
    data['temp_dir'] = "../processed_data/{}/generated_tmp".format(cfg.lang)
    data['model_generated_potentially_faster_code_col'] = "model_generated_potentially_faster_code_col"
    data['slow_code_col'] = "slow_code_col"
    data['reference_code_col'] = "target"
    data['reference_input_col'] = "input"
    data['is_prompt_based'] = False
    data['run_reference'] = True
    data['run_input'] = True
    data['cpu_number'] = 1
    data['process_number'] = int(cfg.process_number)
    write_yaml(data, os.path.join(cfg.output_path, cfg.mode, 'eval_config.yaml'))

    error_file = open(os.path.join(cfg.output_path, cfg.mode, "stderr.txt"), "wb")
    out_file = open(os.path.join(cfg.output_path, cfg.mode, "output.txt"),"wb")
    print("testing......")
    
    if not os.path.exists(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))):
        cmd = 'cd ../pie; python src/codenet_eval/run_eval_feedback.py --eval_config {}'.format(os.path.join(cfg.output_path, cfg.mode, 'eval_config.yaml'))
        child = subprocess.Popen(cmd, shell=True, stdout=out_file, stderr=error_file, bufsize=-1, start_new_session=True)
        while True:
            Flag = child.poll()
            if Flag == 0:
                error_file.close()
                out_file.close()
                break
            else:
                time.sleep(10)
    
    execution_data = []
    with jsonlines.open(os.path.join(cfg.output_path, cfg.mode, 'test_execution_{}.report'.format(cfg.model_name+'test'))) as f:
        for i in f:
            execution_data.append(i)
    
    _calculate_statistics(execution_data, cfg)


def _calculate_statistics(execution_data, cfg):
    """计算统计信息"""


    results = []
    references = []
    hypothesis = []
    ptr = 0
    correct = 0
    faster_count = 0
    unique_count = 0
    input_time_sum = 0
    generated_test_sum = 0
    unique_reference_time_sum = 0
    unique_generated_test_sum = 0

    for i in execution_data:
        acc = i.get('model_generated_potentially_faster_code_col_acc', 0)
        input_time = i.get('input_time_mean', 0)
        generated_time = i.get('model_generated_potentially_faster_code_col_time_mean', input_time)
        reference_time = i.get('reference_time_mean', input_time)
        if input_time is None or reference_time is None:
            continue
        if generated_time is None:
            generated_time = input_time
        results.append([generated_time, input_time, acc])
        for num in range(5):
            time_key = f'model_generated_potentially_faster_code_col_{num}_time_mean'
            std_key = f'model_generated_potentially_faster_code_col_{num}_time_std'
            if time_key in i and std_key in i:
                if i[time_key] == i.get('model_generated_potentially_faster_code_col_time_mean') and \
                   i[std_key] == i.get('model_generated_potentially_faster_code_col_time_std', 0.0):
                    references.append([i.get('code_v1_no_empty_lines', '')])
                    code_key = f'model_generated_potentially_faster_code_col_{num}'
                    hypothesis.append(i.get(code_key, ''))
                    break
        if acc==1:
            correct+=1
        if acc==1 and generated_time<input_time:
            if generated_time<reference_time:
               unique_count+=1
               unique_reference_time_sum += reference_time
               unique_generated_test_sum += generated_time
            if generated_time<input_time*0.9:
                faster_count+=1
            input_time_sum += input_time
            generated_test_sum += generated_time
            ptr += input_time/generated_time -1
        else:
            input_time_sum += input_time
            generated_test_sum += input_time
            ptr += 0
    print(cfg.mode)
    if len(results) > 0:
        print('OPT(%): ', round(100*faster_count/len(results), 2))
        print('SP: ', round(100*ptr/len(results), 2))
    else:
        print('No results to evaluate')

