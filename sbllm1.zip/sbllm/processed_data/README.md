The processed dataset and test cases can be downloaded from https://zenodo.org/records/14096664


The test cases are provided by [pie-perf](https://github.com/madaan/pie-perf/tree/main)
- [Public test cases](https://drive.google.com/file/d/1RcUpZMOR8L2xYYWDZx7I0tHFzFgg7COO/view?usp=share_link)
- [Generated test cases](https://drive.google.com/file/d/1migwX4wpED0gDDxn7gS6q55vWeXIDgId/view?usp=drive_link). These test cases are sourced from [alphacode](https://github.com/google-deepmind/code_contests).